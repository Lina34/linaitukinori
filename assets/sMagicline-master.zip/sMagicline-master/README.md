# sMagicline: Simple Magicline #





sMagicline
===========
Simple Magicline makes your navigation with magicline
 
Installation
============
Include script after the jQuery library.
<script type="text/javascript" src="my.magicline.1.0.min.js"></script>

Usage
=====
Call the plugin:
$(".mainnav").my_magicline();

