## sMagicline Demos / Examples

Here is a demo